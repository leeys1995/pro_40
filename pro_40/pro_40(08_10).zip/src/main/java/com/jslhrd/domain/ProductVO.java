package com.jslhrd.domain;

import lombok.Data;

@Data
public class ProductVO {
	
	private int idx;
	private String p_name;
	private String p_subject;
	private String p_contents;
	private String regdate;
	private String reply;
	private String reply_ok;
	private int idx2;
	private String p_pass;
	
}
