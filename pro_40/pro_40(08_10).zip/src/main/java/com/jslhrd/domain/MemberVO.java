package com.jslhrd.domain;

import lombok.Data;

@Data
public class MemberVO 
{
	private int idx;
	private String name;
	private String userid;
	private String passwd;
	private String userpw;
	private String tel;
	private String tel1;
	private String tel2;
	private String tel3;
	private String email;
	private String email1;
	private String email2;
	private String user_first;
	private String user_last;
	private String rank;
	private String c_code;
	private String c_code1;
	private String c_code2;
	private String c_code3;
	private String pw_code;
	
}
