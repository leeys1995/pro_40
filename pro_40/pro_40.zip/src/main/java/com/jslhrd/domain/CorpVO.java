package com.jslhrd.domain;

import lombok.Data;

@Data
public class CorpVO {
	
	private int idx;
	private String c_code;
	private String c_name;
	private String c_addr1;
	private String c_addr2;
	private String c_tel;
	private String p_intro;
	private String p_mager;
	private String c_video;
	private String c_banner;
	private String c_photo;
	private String c_history;
	private String c_come;
	private String P_photo;
	private int c_readcnt;
	
	
}
