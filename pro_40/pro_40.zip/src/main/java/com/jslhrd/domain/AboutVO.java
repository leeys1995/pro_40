package com.jslhrd.domain;

import lombok.Data;

@Data
public class AboutVO {
	
	private String main_about;

}
