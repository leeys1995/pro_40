package com.jslhrd.domain;

import lombok.Data;

@Data
public class SearchVO {
	private int idx;
	private String h_name;
	private String h_photo;
	private int h_readcnt;
	private String tblname;
	
}
