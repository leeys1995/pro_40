package com.jslhrd.domain;

import lombok.Data;

@Data
public class SearchVO {
	String ho_co;
	String[] booking;
	
	
}
